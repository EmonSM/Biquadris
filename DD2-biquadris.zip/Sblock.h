#ifndef SBLOCK_H
#define SBLOCK_H


#pragma once
#include "block.h"

class Sblock : public Block {


	public:

		Sblock();
		void rotate(int dirction);

};

#endif

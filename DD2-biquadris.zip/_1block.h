#ifndef _1BLOCK_H
#define _1BLOCK_H


#pragma once
#include "block.h"

class _1block : public Block {


	public:

		_1block();
		void rotate(int dirction);

};

#endif

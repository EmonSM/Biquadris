#ifndef IBLOCK_H
#define IBLOCK_H


#pragma once
#include "block.h"

class Iblock : public Block {


	public:

		Iblock();
		void rotate(int dirction);

};

#endif

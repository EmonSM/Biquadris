#include <iostream>
#include "board.h"
#include "display.h"
#include <string> 
#include <sstream>
#include "commands.h"
#include "game.h"


int main(int argc, char* argv[]) {

	

	game g;
	g.runGame(argc, argv);

}
